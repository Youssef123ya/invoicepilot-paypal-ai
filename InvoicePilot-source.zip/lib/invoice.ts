import { z } from "zod";
export const currencies = ["USD", "EUR", "GBP"] as const;
export const itemSchema = z.object({
  name: z.string().trim().min(1).max(150),
  quantity: z.number().positive().max(10000).refine(v => Math.abs(v * 100 - Math.round(v * 100)) < 0.00001, "Use at most two decimal places for quantity."),
  unitPrice: z.number().min(0.01).max(100000).refine(v => Math.abs(v * 100 - Math.round(v * 100)) < 0.00001, "Use at most two decimal places for price."),
});
export const invoiceSchema = z.object({
  clientName: z.string().trim().min(1).max(100), clientEmail: z.string().trim().email().max(200), businessName: z.string().trim().min(1).max(150),
  currency: z.enum(currencies), terms: z.enum(["DUE_ON_RECEIPT", "NET_15", "NET_30"]), note: z.string().trim().max(1000), items: z.array(itemSchema).min(1).max(20),
});
export type InvoiceDraft = z.infer<typeof invoiceSchema>;
export type InvoiceRecord = { id: string; number: string; status: string; amount: string; currency: string; client: string; payerUrl?: string; mode: "sandbox"; };
export function totalCents(items: InvoiceDraft["items"]) { return items.reduce((sum, i) => sum + Math.round(Math.round(i.unitPrice * 100) * i.quantity), 0); }
export function paypalPayload(draft: InvoiceDraft) {
  return {
    detail: { currency_code: draft.currency, note: draft.note || "Thank you for your business.", payment_term: { term_type: draft.terms } },
    invoicer: { business_name: draft.businessName },
    primary_recipients: [{ billing_info: { name: { full_name: draft.clientName }, email_address: draft.clientEmail } }],
    items: draft.items.map(i => ({ name: i.name, quantity: String(i.quantity), unit_amount: { currency_code: draft.currency, value: i.unitPrice.toFixed(2) } })),
    configuration: { allow_tip: false, partial_payment: { allow_partial_payment: false } },
  };
}
export function safePayerUrl(value: unknown): string | undefined {
  if (typeof value !== "string") return;
  try { const u = new URL(value); if (u.protocol === "https:" && (u.hostname === "sandbox.paypal.com" || u.hostname.endsWith(".sandbox.paypal.com"))) return u.href; } catch {}
}
export function invoiceRecord(data: any): InvoiceRecord {
  const link = data.detail?.metadata?.recipient_view_url || data.links?.find((l: any) => l.rel === "payer-view")?.href;
  return { id: data.id, number: data.detail?.invoice_number || data.id, status: data.status || "DRAFT", amount: data.amount?.value || "0.00", currency: data.amount?.currency_code || data.detail?.currency_code || "USD", client: data.primary_recipients?.[0]?.billing_info?.name?.full_name || data.primary_recipients?.[0]?.billing_info?.email_address || "Client", payerUrl: safePayerUrl(link), mode: "sandbox" };
}
export const sampleNotes = "For Maya at hello@example.com: 6 hours of landing page design at $75 per hour, plus 1 brand icon set for $150. Payment due in 15 days. Thank her for the collaboration.";
export const sampleDraft: InvoiceDraft = { businessName: "Your Studio", clientName: "Maya", clientEmail: "hello@example.com", currency: "USD", terms: "NET_15", note: "Thank you for the collaboration!", items: [{ name: "Landing page design", quantity: 6, unitPrice: 75 }, { name: "Brand icon set", quantity: 1, unitPrice: 150 }] };
