$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath (Split-Path -Parent $PSScriptRoot)
Write-Host 'InvoicePilot: secure LOCAL setup. Enter sandbox credentials only.'
Write-Host 'Values are hidden and saved in ignored .dev.vars; they will not be printed.'
function Read-PrivateValue([string] $Prompt) {
    $taskSecure = Read-Host $Prompt -AsSecureString
    $taskPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($taskSecure)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($taskPointer) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($taskPointer) }
}
$taskClientId = Read-PrivateValue 'PayPal SANDBOX Client ID'
$taskClientSecret = Read-PrivateValue 'PayPal SANDBOX Secret'
$taskGeminiKey = Read-PrivateValue 'Gemini API key'
if ([string]::IsNullOrWhiteSpace($taskClientId) -or [string]::IsNullOrWhiteSpace($taskClientSecret) -or [string]::IsNullOrWhiteSpace($taskGeminiKey)) { throw 'All three connection values are required. No file was written.' }
$taskLines = @(
    'PAYPAL_CLIENT_ID=' + (ConvertTo-Json -InputObject $taskClientId -Compress)
    'PAYPAL_CLIENT_SECRET=' + (ConvertTo-Json -InputObject $taskClientSecret -Compress)
    'GEMINI_API_KEY=' + (ConvertTo-Json -InputObject $taskGeminiKey -Compress)
    'GEMINI_MODEL="gemini-3.5-flash-lite"'
)
if (Test-Path -LiteralPath '.dev.vars') { $taskAnswer = Read-Host 'Replace existing local connections? Type REPLACE'; if ($taskAnswer -ne 'REPLACE') { Write-Host 'Kept existing connections.'; exit } }
Set-Content -LiteralPath '.dev.vars' -Value $taskLines -Encoding utf8
$taskClientId = $null; $taskClientSecret = $null; $taskGeminiKey = $null; $taskLines = $null
Write-Host 'Saved locally. Restart the development server, sign in locally, and test a draft.'
Write-Host 'Hosted preview secrets must be configured separately; this script does not upload them.'


