$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath (Split-Path -Parent $PSScriptRoot)
Write-Host 'InvoicePilot: secure LOCAL setup. Enter sandbox credentials only.'
Write-Host 'Values are hidden and saved in ignored .dev.vars; they will not be printed.'
function Read-PrivateValue([string] $Prompt) {
    $taskSecure = Read-Host $Prompt -AsSecureString
    if ($null -eq $taskSecure -or $taskSecure.Length -eq 0) { return '' }
    $taskPointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($taskSecure)
    try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($taskPointer) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($taskPointer) }
}
$taskClientId = Read-PrivateValue 'PayPal SANDBOX Client ID'
$taskClientSecret = Read-PrivateValue 'PayPal SANDBOX Secret'
if ([string]::IsNullOrWhiteSpace($taskClientId) -or [string]::IsNullOrWhiteSpace($taskClientSecret)) { throw 'Both PayPal Sandbox values are required. No file was written.' }
$taskGeminiKey = Read-PrivateValue 'Gemini API key (optional, press Enter to skip)'
$taskLines = @(
    'PAYPAL_CLIENT_ID=' + (ConvertTo-Json -InputObject $taskClientId -Compress)
    'PAYPAL_CLIENT_SECRET=' + (ConvertTo-Json -InputObject $taskClientSecret -Compress)
)
if (-not [string]::IsNullOrWhiteSpace($taskGeminiKey)) {
    $taskLines += 'GEMINI_API_KEY=' + (ConvertTo-Json -InputObject $taskGeminiKey -Compress)
    $taskLines += 'GEMINI_MODEL="gemini-3.5-flash-lite"'
}
if (Test-Path -LiteralPath '.dev.vars') { $taskAnswer = Read-Host 'Replace existing local connections? Type REPLACE'; if ($taskAnswer -ne 'REPLACE') { Write-Host 'Kept existing connections.'; exit } }
Set-Content -LiteralPath '.dev.vars' -Value $taskLines -Encoding utf8
$taskClientId = $null; $taskClientSecret = $null; $taskGeminiKey = $null; $taskLines = $null
Write-Host 'Saved locally. Restart the development server and sign in to InvoicePilot.'
Write-Host 'Hosted preview secrets must be configured separately; this script does not upload them.'


