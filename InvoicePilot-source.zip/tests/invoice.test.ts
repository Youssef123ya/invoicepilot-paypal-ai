import { test } from "node:test";
import assert from "node:assert/strict";
import { invoiceRecord, invoiceSchema, paypalPayload, safePayerUrl, sampleDraft, totalCents } from "../lib/invoice.ts";
import { createInvoice, draftWithAI, paypal } from "../lib/services.ts";
test("invoice arithmetic rounds each line to cents and handles fractional quantities", () => {
  assert.equal(totalCents(sampleDraft.items), 60000);
  assert.equal(totalCents([{ name: "Work", quantity: 1.5, unitPrice: 0.99 }, { name: "More work", quantity: 1, unitPrice: 0.1 }]), 159);
});
test("unsafe and incomplete invoice input is rejected", () => {
  for (const patch of [{ clientEmail: "wrong" }, { items: [] }, { currency: "XYZ" }, { items: [{ name: "Work", quantity: -1, unitPrice: 50 }] }, { items: [{ name: "Work", quantity: 1, unitPrice: 0 }] }, { items: [{ name: "Work", quantity: 1, unitPrice: 1.001 }] }]) assert.equal(invoiceSchema.safeParse({ ...sampleDraft, ...patch }).success, false);
});
test("PayPal payload retains reviewed values and decimal price formatting", () => { const p = paypalPayload(sampleDraft); assert.equal(p.items[0].unit_amount.value, "75.00"); assert.equal(p.detail.payment_term.term_type, "NET_15"); assert.equal(p.primary_recipients[0].billing_info.email_address, "hello@example.com"); });
test("payment URLs are restricted to the real PayPal sandbox origin", () => { assert.ok(safePayerUrl("https://www.sandbox.paypal.com/invoice/p/#123")); for (const url of ["javascript:alert(1)", "https://sandbox.paypal.com.evil.test/", "https://www.paypal.com/", "http://sandbox.paypal.com/"]) assert.equal(safePayerUrl(url), undefined); });
test("invoice refresh can distinguish a full buyer payment from pending or recorded payments", () => {
  for (const status of ["UNPAID", "PAYMENT_PENDING", "PARTIALLY_PAID", "MARKED_AS_PAID", "PAID"]) {
    const record = invoiceRecord({
      id: "INV2-TEST-1234",
      status,
      amount: { value: "5.00", currency_code: "USD" },
    });
    assert.equal(record.id, "INV2-TEST-1234");
    assert.equal(record.status, status);
    assert.equal(record.mode, "sandbox");
  }
});
test("missing credentials fail before any network request", async () => { await assert.rejects(() => paypal({}, "/v2/invoicing/invoices"), /Connect your PayPal/); await assert.rejects(() => draftWithAI({}, "work notes", "USD"), /Connect Gemini/); });
test("create uses sandbox OAuth and stable idempotency key; link-only responses are resolved", async () => {
  const calls: { url: string; options: RequestInit }[] = [];
  const fake = (async (url: any, options: any) => { calls.push({ url, options }); if (String(url).endsWith("/token")) return Response.json({ access_token: "mock-token" }); if (options.method === "POST") return Response.json({ href: "https://api-m.sandbox.paypal.com/v2/invoicing/invoices/INV2-TEST-1234" }); return Response.json({ id: "INV2-TEST-1234", status: "DRAFT", amount: { value: "600.00", currency_code: "USD" } }); }) as typeof fetch;
  const result = await createInvoice({ PAYPAL_CLIENT_ID: "test", PAYPAL_CLIENT_SECRET: "test" }, sampleDraft, "stable-request", fake);
  assert.equal(result.id, "INV2-TEST-1234"); assert.equal(result.status, "DRAFT"); assert.ok(calls.every(c => c.url.startsWith("https://api-m.sandbox.paypal.com/"))); assert.equal((calls[1].options.headers as any)["PayPal-Request-Id"], "stable-request");
});
test("provider errors do not expose provider bodies or secrets", async () => { const fake = (async () => Response.json({ secret: "never-show", error: "private-provider-message" }, { status: 401 })) as typeof fetch; await assert.rejects(() => paypal({ PAYPAL_CLIENT_ID: "test", PAYPAL_CLIENT_SECRET: "test" }, "/x", "GET", undefined, undefined, fake), e => { assert.ok(e instanceof Error); assert.doesNotMatch(e.message, /never-show|private-provider-message/); return true; }); });
test("AI request uses structured output, stateless input, and retains missing amounts as null", async () => { const fake = (async (_url: any, options: any) => { const body = JSON.parse(options.body); assert.equal(body.contents.length, 1); assert.equal(body.generationConfig.responseMimeType, "application/json"); return Response.json({ candidates: [{ content: { parts: [{ type: "text", text: JSON.stringify({ clientName: "Maya", clientEmail: "", note: "", items: [{ name: "Design", quantity: null, unitPrice: null }], questions: ["What is the agreed rate?"] }) }] } }] }); }) as typeof fetch; const draft = await draftWithAI({ GEMINI_API_KEY: "test" }, "Design work with missing rate", "USD", fake); assert.equal(draft.items[0].unitPrice, null); assert.equal(draft.questions.length, 1); });

