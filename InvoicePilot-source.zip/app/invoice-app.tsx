"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowDownToLine, ArrowRight, Check, CheckCircle2, ChevronRight, CircleHelp, Copy, ExternalLink, FileText, FolderClock, Link2, LoaderCircle, Plus, RefreshCw, Send, ShieldCheck, Sparkles, Trash2, X } from "lucide-react";
import { currencies, invoiceSchema, sampleDraft, sampleNotes, totalCents, type InvoiceDraft, type InvoiceRecord } from "../lib/invoice";

const emptyDraft = (): InvoiceDraft => ({ businessName: "", clientName: "", clientEmail: "", currency: "USD", terms: "NET_15", note: "", items: [{ name: "", quantity: 1, unitPrice: 0 }] });
const money = (value: number, currency: string) => new Intl.NumberFormat("en-US", { style: "currency", currency }).format(value);
async function api(path: string, body?: unknown) {
  const r = await fetch(`/api/${path}`, { ...(body ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) } : {}), cache: "no-store" });
  const data: any = await r.json();
  if (!r.ok) throw new Error([data.error, ...(data.fields || [])].join(" "));
  return data;
}
type View = "create" | "invoices" | "connections";
export default function InvoiceApp() {
  const [view, setView] = useState<View>("create");
  const [draft, setDraft] = useState<InvoiceDraft>(emptyDraft);
  const [notes, setNotes] = useState("");
  const [sample, setSample] = useState(false);
  const [reviewed, setReviewed] = useState(false);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [questions, setQuestions] = useState<string[]>([]);
  const [connection, setConnection] = useState({ paypal: false, ai: false });
  const [created, setCreated] = useState<InvoiceRecord | null>(null);
  const [invoices, setInvoices] = useState<InvoiceRecord[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [confirmSend, setConfirmSend] = useState(false);
  const createKey = useRef("");
  const sendKey = useRef("");
  const locked = Boolean(created) || Boolean(busy);
  const valid = invoiceSchema.safeParse(draft).success;
  const total = totalCents(draft.items) / 100;

  useEffect(() => { api("connections").then(setConnection).catch(() => {}); }, []);
  function edit(next: InvoiceDraft) { setDraft(next); setReviewed(false); createKey.current = ""; setError(""); }
  function update<K extends keyof InvoiceDraft>(key: K, value: InvoiceDraft[K]) { edit({ ...draft, [key]: value }); }
  function reset() { setDraft(emptyDraft()); setNotes(""); setSample(false); setReviewed(false); setCreated(null); setQuestions([]); setError(""); setNotice(""); createKey.current = ""; sendKey.current = ""; setView("create"); }
  function loadExample() { setDraft(structuredClone(sampleDraft)); setNotes(sampleNotes); setSample(true); setReviewed(false); setCreated(null); setQuestions([]); setError(""); setNotice("Sample loaded. This is a prepared example, not an AI or PayPal result."); createKey.current = ""; }
  async function run(label: string, work: () => Promise<void>) { setBusy(label); setError(""); setNotice(""); try { await work(); } catch (e) { setError(e instanceof Error ? e.message : "Something went wrong. Please try again."); } finally { setBusy(""); } }
  function generate() { void run("draft", async () => {
    const result = await api("draft", { notes, currency: draft.currency });
    edit({ ...draft, clientName: result.clientName, clientEmail: result.clientEmail, note: result.note, items: result.items.map((i: any) => ({ ...i, quantity: i.quantity ?? 0, unitPrice: i.unitPrice ?? 0 })) });
    setQuestions(result.questions); setSample(false); setNotice("AI draft ready. Check every line, amount, and recipient before creating it.");
  }); }
  function create() { void run("create", async () => {
    if (!reviewed || sample || !valid) throw new Error("Review all invoice fields before creating your sandbox invoice.");
    createKey.current ||= crypto.randomUUID();
    const record = await api("invoices", { invoice: draft, reviewed: true, requestId: createKey.current });
    setCreated(record); setNotice("Draft created in PayPal Sandbox. You can now activate its payment link.");
  }); }
  function send() { setConfirmSend(false); void run("send", async () => {
    sendKey.current ||= crypto.randomUUID();
    const record = await api(`invoices/${created!.id}/send`, { confirmed: true, requestId: sendKey.current });
    setCreated(record); setNotice("Sandbox invoice activated. Copy its payment link to test with your sandbox buyer account.");
  }); }
  function refresh(record: InvoiceRecord) { void run("refresh", async () => { const current = await api(`invoices/${record.id}`); if (created?.id === current.id) setCreated(current); setInvoices(prev => prev.map(i => i.id === current.id ? current : i)); setNotice("Status refreshed from PayPal Sandbox."); }); }
  function listInvoices() { setView("invoices"); if (!connection.paypal) { setError(""); setNotice(""); return; } void run("list", async () => { const data = await api("invoices"); setInvoices(data.invoices); setLoaded(true); }); }
  function saveDraft() { try { localStorage.setItem("invoicepilot-draft", JSON.stringify({ draft, notes, sample })); setNotice("Draft saved in this browser on this device."); } catch { setError("This browser could not save your draft."); } }
  function restoreDraft() { try { const value = localStorage.getItem("invoicepilot-draft"); if (!value) return setNotice("No saved draft in this browser yet."); const saved = JSON.parse(value); setDraft(saved.draft); setNotes(saved.notes || ""); setSample(Boolean(saved.sample)); setReviewed(false); setCreated(null); setNotice("Saved draft restored. Please review it again."); } catch { setError("Your saved draft could not be restored."); } }
  function exportDraft() { const blob = new Blob([JSON.stringify({ ...draft, total: total.toFixed(2), source: sample ? "prepared sample" : "user draft" }, null, 2)], { type: "application/json" }); const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "invoicepilot-draft.json"; a.click(); URL.revokeObjectURL(a.href); }
  async function copyLink(url: string) { try { await navigator.clipboard.writeText(url); setNotice("Payment link copied."); } catch { setError("Copy is unavailable. Open the payment link and copy its address."); } }

  return <div className="app-shell">
    <aside className="sidebar">
      <a className="brand" href="/" aria-label="InvoicePilot home"><span className="brand-mark"><FileText size={23} /></span>Invoice<span>Pilot</span></a>
      <div className="workspace"><span className="workspace-avatar">YS</span><div>Your workspace<small>Freelancer studio</small></div><span className="workspace-chevron">⌄</span></div>
      <p className="nav-label">WORKSPACE</p>
      <nav aria-label="Main navigation">
        <button className={view === "create" ? "nav-item active" : "nav-item"} onClick={() => setView("create")}><Plus size={18} />Create invoice</button>
        <button className={view === "invoices" ? "nav-item active" : "nav-item"} onClick={listInvoices}><FolderClock size={18} />Invoices</button>
        <button className={view === "connections" ? "nav-item active" : "nav-item"} onClick={() => setView("connections")}><Link2 size={18} />Connections<span className="nav-dot" /></button>
      </nav>
      <div className="sidebar-bottom"><div className="sandbox-card"><ShieldCheck size={22} /><strong>A safe space to build</strong><p>All PayPal actions use sandbox accounts and test money.</p><span className="sandbox-tag"><i />Sandbox environment</span></div><a className="help-link" href="https://developer.paypal.com/invoicing/about" target="_blank" rel="noreferrer"><CircleHelp size={17} />Invoicing guide<ExternalLink size={14} /></a></div>
    </aside>
    <main>
      <header className="topbar"><div>Workspace<ChevronRight size={14} /><strong>{view === "create" ? "Create invoice" : view === "invoices" ? "Invoices" : "Connections"}</strong></div><span className="environment"><i />PayPal Sandbox</span><span className="user-avatar">Y</span></header>
      <div className="main-content">
        <div className="page-heading"><div><p className="eyebrow">LESS ADMIN. MORE CREATING.</p><h1>{view === "create" ? "Good work deserves a great invoice." : view === "invoices" ? "Keep every invoice in sight." : "Your tools, connected."}</h1><p>{view === "create" ? "Turn your work notes into a polished invoice. You stay in control." : view === "invoices" ? "Real invoices and their latest status, straight from PayPal Sandbox." : "Connect your sandbox and AI accounts to bring your workflow to life."}</p></div>{view === "create" && <button className="button secondary" onClick={reset} disabled={Boolean(busy)}><Plus size={16} />New invoice</button>}</div>
        {(error || notice) && <div className={`message ${error ? "error" : "success"}`} role={error ? "alert" : "status"}>{error || notice}<button aria-label="Dismiss message" onClick={() => { setError(""); setNotice(""); }}><X size={16} /></button></div>}
        {view === "create" && <>
          <div className="journey"><div className="journey-step current"><span>1</span><strong>Describe the work</strong><small>Your notes, your words</small></div><div className={`journey-step ${draft.clientName ? "current" : ""}`}><span>2</span><strong>Review your invoice</strong><small>A human check, always</small></div><div className={`journey-step ${created ? "current" : ""}`}><span>{created ? <Check size={14} /> : "3"}</span><strong>Create with PayPal</strong><small>Ready when you are</small></div></div>
          <div className="editor-grid">
            <section className="notes-column">
              <div className="panel notes-panel"><div className="section-title"><span className="icon-tile"><Sparkles size={19} /></span><div><h2>Start with the story</h2><p>Tell us what you worked on.</p></div><span className="pill">AI ASSISTED</span></div>
                <label className="field-label" htmlFor="work-notes">Work notes</label><textarea id="work-notes" className="work-notes" placeholder="I designed a landing page for Maya. 6 hours at $75/hour, plus a $150 icon set. Her email is…" value={notes} maxLength={6000} disabled={locked} onChange={e => setNotes(e.target.value)} />
                <div className="textarea-footer"><span>Include the client, work, quantities & rates.</span><span>{notes.length}/6000</span></div>
                <div className="prompt-controls"><label>Invoice currency<select value={draft.currency} disabled={locked} onChange={e => update("currency", e.target.value as InvoiceDraft["currency"])}>{currencies.map(c => <option key={c}>{c}</option>)}</select></label><button className="button primary" onClick={generate} disabled={locked || notes.trim().length < 10 || !connection.ai}>{busy === "draft" ? <LoaderCircle className="spin" size={17} /> : <Sparkles size={17} />}{busy === "draft" ? "Drafting…" : "Draft with AI"}</button></div>
                {!connection.ai && <p className="connection-note">Connect Gemini to use AI drafting. <button onClick={() => setView("connections")}>Set up connections <ArrowRight size={13} /></button></p>}
                <div className="example"><span>Just looking around?</span><button onClick={loadExample} disabled={Boolean(busy)}>Try a sample invoice <ArrowRight size={14} /></button></div>
              </div>
              {questions.length > 0 && <div className="questions"><strong>A few details need your attention</strong><ul>{questions.map((q, i) => <li key={i}>{q}</li>)}</ul><p>Fill in the missing details in the invoice before continuing.</p></div>}
              <div className="intent-card"><span className="icon-tile pale"><ShieldCheck size={21} /></span><div><h3>You’re the final check.</h3><p>AI prepares a draft. You review the details and decide when it goes to PayPal.</p></div></div>
              <div className="draft-tools"><button onClick={saveDraft} disabled={locked}><ArrowDownToLine size={15} />Save on this device</button><button onClick={restoreDraft} disabled={locked}><FolderClock size={15} />Restore draft</button><button onClick={exportDraft}><ExternalLink size={14} />Export JSON</button></div>
              <p className="privacy-note">Notes go to Gemini only when you choose “Draft with AI.” Saved drafts stay in this browser.</p>
            </section>
            <section className="invoice-column"><div className="invoice-topline"><h2><FileText size={17} />Invoice preview</h2><span className={`status ${sample ? "sample" : ""}`}>{sample ? "PREPARED SAMPLE" : created ? created.status.replaceAll("_", " ") : "DRAFT"}</span></div>
              <div className="invoice-paper"><div className="paper-heading"><div className="paper-logo"><FileText size={21} /></div><div><span className="paper-kicker">INVOICE</span><small>{created?.number || "Your next invoice"}</small></div></div>
                <fieldset disabled={locked}><div className="paper-business"><label className="field-label" htmlFor="business">FROM</label><input id="business" className="business-name" placeholder="Your business or studio name" maxLength={150} value={draft.businessName} onChange={e => update("businessName", e.target.value)} /></div>
                  <div className="recipient-grid"><div><label className="field-label" htmlFor="client-name">BILL TO</label><input id="client-name" placeholder="Client name" value={draft.clientName} maxLength={100} onChange={e => update("clientName", e.target.value)} /><input aria-label="Client email" type="email" placeholder="client@example.com" value={draft.clientEmail} maxLength={200} onChange={e => update("clientEmail", e.target.value)} /></div><div><label className="field-label" htmlFor="terms">PAYMENT TERMS</label><select id="terms" value={draft.terms} onChange={e => update("terms", e.target.value as InvoiceDraft["terms"])}><option value="DUE_ON_RECEIPT">Due on receipt</option><option value="NET_15">Within 15 days</option><option value="NET_30">Within 30 days</option></select><span className="currency-label">Currency · {draft.currency}</span></div></div>
                  <div className="line-header"><span>DESCRIPTION</span><span>QTY</span><span>RATE</span><span>AMOUNT</span><span /></div>
                  <div className="line-items">{draft.items.map((item, index) => <div className="line-item" key={index}><input aria-label={`Item ${index + 1} description`} placeholder="Service or deliverable" maxLength={150} value={item.name} onChange={e => update("items", draft.items.map((i, n) => n === index ? { ...i, name: e.target.value } : i))} /><input aria-label={`Item ${index + 1} quantity`} type="number" min="0.01" max="10000" step="0.01" value={item.quantity || ""} placeholder="—" onChange={e => update("items", draft.items.map((i, n) => n === index ? { ...i, quantity: Number(e.target.value) } : i))} /><input aria-label={`Item ${index + 1} unit price`} type="number" min="0.01" max="100000" step="0.01" value={item.unitPrice || ""} placeholder="0.00" onChange={e => update("items", draft.items.map((i, n) => n === index ? { ...i, unitPrice: Number(e.target.value) } : i))} /><span className="line-amount">{money(totalCents([item]) / 100, draft.currency)}</span><button aria-label={`Remove item ${index + 1}`} className="delete-row" disabled={draft.items.length === 1 || locked} onClick={() => update("items", draft.items.filter((_, n) => n !== index))}><Trash2 size={13} /></button></div>)}</div>
                  <button className="add-line" disabled={draft.items.length >= 20 || locked} onClick={() => update("items", [...draft.items, { name: "", quantity: 1, unitPrice: 0 }])}><Plus size={14} />Add a line item</button>
                  <div className="totals"><div><span>Subtotal</span><span>{money(total, draft.currency)}</span></div><div className="total-due"><strong>Total due</strong><strong>{money(total, draft.currency)}<small>{draft.currency}</small></strong></div></div>
                  <div className="invoice-note"><label className="field-label" htmlFor="invoice-note">A NOTE FOR YOUR CLIENT</label><textarea id="invoice-note" placeholder="Thank you for your business." value={draft.note} maxLength={1000} onChange={e => update("note", e.target.value)} /></div>
                </fieldset><div className="paper-footer"><ShieldCheck size={13} />{sample ? "Sample preview · no AI call or PayPal invoice created" : "PayPal Sandbox · test invoices only"}</div>
              </div>
              {sample ? <div className="sample-action"><p>This prepared example shows the review experience.</p><button className="button primary full" onClick={reset}>Start my own invoice <ArrowRight size={16} /></button></div> : created ? <div className="created-actions"><p><CheckCircle2 size={17} />Invoice {created.status === "DRAFT" ? "draft saved" : "activated"} in PayPal Sandbox</p>{created.status === "DRAFT" && <button className="button primary full" disabled={Boolean(busy)} onClick={() => setConfirmSend(true)}><Send size={16} />Activate sandbox payment link</button>}{created.payerUrl && <div className="link-actions"><a className="button primary" href={created.payerUrl} target="_blank" rel="noreferrer">Open payment link<ExternalLink size={14} /></a><button className="button secondary" onClick={() => copyLink(created.payerUrl!)}><Copy size={15} />Copy</button></div>}<button className="button secondary full" disabled={Boolean(busy)} onClick={() => refresh(created)}><RefreshCw size={15} />Refresh PayPal status</button></div> : <div className="review-action"><label className="review-checkbox"><input type="checkbox" checked={reviewed} onChange={e => setReviewed(e.target.checked)} disabled={locked} /><span>I’ve checked the client, line items, and total.</span></label><button className="button primary full create-paypal" onClick={create} disabled={!valid || !reviewed || !connection.paypal || Boolean(busy)}>{busy === "create" ? <LoaderCircle className="spin" size={17} /> : <ShieldCheck size={17} />}{busy === "create" ? "Creating in PayPal…" : "Create PayPal sandbox invoice"}<ArrowRight size={17} /></button><p>{!connection.paypal ? <button onClick={() => setView("connections")}>Connect PayPal Sandbox to create your invoice.</button> : !valid ? "Complete all client details and add valid quantities and prices." : "Creates a draft. You choose when to activate the payment link."}</p></div>}
            </section>
          </div>
        </>}
        {view === "invoices" && <section className="panel invoice-list"><div className="section-title"><h2>Your sandbox invoices</h2><button className="button secondary" onClick={listInvoices} disabled={Boolean(busy)}><RefreshCw size={15} />Refresh</button></div>{!connection.paypal ? <div className="empty-state"><Link2 size={32} /><h3>Connect PayPal to see your invoices</h3><p>Your invoices will appear here after your sandbox is connected.</p><button className="button primary" onClick={() => setView("connections")}>Set up PayPal<ArrowRight size={16} /></button></div> : loaded && invoices.length === 0 ? <div className="empty-state"><FileText size={32} /><h3>A fresh start</h3><p>Create your first sandbox invoice and it will appear here.</p><button className="button primary" onClick={reset}>Create an invoice</button></div> : busy === "list" ? <div className="empty-state"><LoaderCircle className="spin" />Loading from PayPal…</div> : <div className="table-scroll"><table><thead><tr><th>Invoice</th><th>Client</th><th>Total</th><th>Status</th><th>Actions</th></tr></thead><tbody>{invoices.map(i => <tr key={i.id}><td><strong>{i.number}</strong><small>{i.id}</small></td><td>{i.client}</td><td>{money(Number(i.amount), i.currency)}</td><td><span className="status">{i.status.replaceAll("_", " ")}</span></td><td><button className="text-button" disabled={Boolean(busy)} onClick={() => refresh(i)}>Refresh</button>{i.payerUrl && <a href={i.payerUrl} target="_blank" rel="noreferrer">Open link ↗</a>}</td></tr>)}</tbody></table></div>}</section>}
        {view === "connections" && <>
          <div className="connections-grid"><section className="panel connection-card"><div className="connection-header"><span className="provider paypal">P</span><span className={`status ${connection.paypal ? "connected" : ""}`}>{connection.paypal ? "CONFIGURED" : "SETUP NEEDED"}</span></div><h2>PayPal Sandbox</h2><p>Create and track invoices using test accounts and test money.</p><ol><li>Sign in or create your PayPal developer account.</li><li>Under Apps & Credentials, select <strong>Sandbox</strong> and create an app.</li><li>Keep your Client ID and Secret ready for the secure local setup.</li><li>Under Testing Tools → Sandbox Accounts, find your business account and a personal buyer account.</li></ol><a className="button secondary" href="https://developer.paypal.com/dashboard/" target="_blank" rel="noreferrer">Open PayPal Developer<ExternalLink size={15} /></a></section>
          <section className="panel connection-card"><div className="connection-header"><span className="provider gemini"><Sparkles size={25} /></span><span className={`status ${connection.ai ? "connected" : ""}`}>{connection.ai ? "CONFIGURED" : "SETUP NEEDED"}</span></div><h2>Gemini</h2><p>Turn work notes into structured invoice details for your review.</p><ol><li>Sign in to Google AI Studio with your Google account.</li><li>Create an API key in an available project.</li><li>Review the account’s model access, quotas, and billing settings.</li><li>Keep the key ready for the secure local setup. Your key stays on the server.</li></ol><a className="button secondary" href="https://aistudio.google.com/apikey" target="_blank" rel="noreferrer">Open Google AI Studio<ExternalLink size={15} /></a></section></div>
          <div className="connection-next"><ShieldCheck size={25} /><div><h3>Ready with both accounts?</h3><a href="/signin-with-chatgpt?return_to=/" target="_top">Sign in to this workspace</a><p>Tell Codex “accounts ready” to connect them securely. Don’t paste secrets into chat. Your project includes a setup script with hidden prompts.</p><p>Connection status shows configuration, not a successful provider test. We’ll test both integrations after setup.</p></div></div><button className="button secondary" onClick={() => void run("connections", async () => { setConnection(await api("connections")); setNotice("Connection configuration refreshed."); })}><RefreshCw size={15} />Check connections</button>
        </>}
        <footer className="app-footer"><span>InvoicePilot <span className="footer-dot">·</span> Made for the work you love.</span><span><ShieldCheck size={13} />PayPal AI Hackathon · Sandbox build</span></footer>
      </div>
    </main>
    {confirmSend && <div className="modal-backdrop"><section className="modal" role="dialog" aria-modal="true" aria-labelledby="send-title"><span className="icon-tile"><Send size={22} /></span><h2 id="send-title">Activate this sandbox invoice?</h2><p>This activates the PayPal sandbox payment link for {draft.clientName}, totaling {money(total, draft.currency)}. Email notifications are disabled. Use a sandbox buyer to test payment.</p><div className="modal-actions"><button autoFocus className="button secondary" onClick={() => setConfirmSend(false)}>Keep as draft</button><button className="button primary" onClick={send}>Activate link<ArrowRight size={15} /></button></div></section></div>}
  </div>;
}

