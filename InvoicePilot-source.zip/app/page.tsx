import InvoiceApp from "./invoice-app";
export default function Home() { return <InvoiceApp />; }
