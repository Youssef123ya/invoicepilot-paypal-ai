import { env } from "cloudflare:workers";
import { z } from "zod";
import { getChatGPTUser } from "../../chatgpt-auth";
import { invoiceRecord, invoiceSchema, currencies } from "../../../lib/invoice";
import { AppError, createInvoice, draftWithAI, paypal, type Connections } from "../../../lib/services";
export const dynamic = "force-dynamic";
const config = () => env as unknown as Connections;
const json = (data: unknown, status = 200) => Response.json(data, { status, headers: { "Cache-Control": "no-store" } });
async function authorize(request: Request, write: boolean) {
  if (!await getChatGPTUser()) throw new AppError("Sign in to use your connected accounts.", 401);
  if (write && request.headers.get("origin") !== new URL(request.url).origin) throw new AppError("Please make this request from InvoicePilot.", 403);
}
async function route(request: Request) {
  try {
    const path = new URL(request.url).pathname.replace(/^\/api\//, "");
    const c = config();
    if (path === "connections" && request.method === "GET") return json({ paypal: Boolean(c.PAYPAL_CLIENT_ID && c.PAYPAL_CLIENT_SECRET), ai: Boolean(c.GEMINI_API_KEY), environment: "sandbox" });
    await authorize(request, request.method !== "GET");
    if (Number(request.headers.get("content-length") || 0) > 25000) throw new AppError("Request is too large.", 413);
    if (path === "draft" && request.method === "POST") {
      const body = z.object({ notes: z.string().trim().min(10).max(6000), currency: z.enum(currencies) }).parse(await request.json());
      const draft = await draftWithAI(c, body.notes, body.currency);
      return json(z.object({ clientName: z.string().max(100), clientEmail: z.string().max(200), note: z.string().max(1000), items: z.array(z.object({ name: z.string().max(150), quantity: z.number().positive().max(10000).nullable(), unitPrice: z.number().positive().max(100000).nullable() })).max(20), questions: z.array(z.string().max(500)).max(25) }).parse(draft));
    }
    if (path === "invoices" && request.method === "POST") {
      const body = z.object({ invoice: invoiceSchema, requestId: z.string().uuid(), reviewed: z.literal(true) }).parse(await request.json());
      return json(await createInvoice(c, body.invoice, body.requestId), 201);
    }
    if (path === "invoices" && request.method === "GET") { const list = await paypal(c, "/v2/invoicing/invoices?page=1&page_size=30&total_required=false"); return json({ invoices: (list.items || []).map(invoiceRecord) }); }
    const match = path.match(/^invoices\/(INV2-[A-Z0-9-]+)(\/send)?$/);
    if (match) {
      if (match[2] && request.method === "POST") {
        const body = z.object({ confirmed: z.literal(true), requestId: z.string().uuid() }).parse(await request.json());
        await paypal(c, `/v2/invoicing/invoices/${match[1]}/send`, "POST", { send_to_recipient: false, send_to_invoicer: false }, body.requestId);
      } else if (request.method !== "GET" || match[2]) throw new AppError("Action not found.", 404);
      return json(await paypal(c, `/v2/invoicing/invoices/${match[1]}`).then(invoiceRecord));
    }
    throw new AppError("Action not found.", 404);
  } catch (error) {
    if (error instanceof z.ZodError) return json({ error: "Please check the invoice fields.", fields: error.issues.map(i => `${i.path.join(".")}: ${i.message}`) }, 400);
    if (error instanceof AppError) return json({ error: error.message }, error.status);
    if (error instanceof SyntaxError) return json({ error: "The request must contain valid JSON." }, 400);
    if (error instanceof Error && ["AbortError", "TimeoutError"].includes(error.name)) return json({ error: "The service took too long to respond. Your draft is still here. Before retrying invoice creation, check your PayPal invoice list." }, 504);
    return json({ error: "The request could not finish. Please try again." }, 500);
  }
}
export const GET = route;
export const POST = route;
